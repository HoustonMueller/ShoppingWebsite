const express = require("express")
const path = require("path")
const fs = require("fs")
const sqlite = require("better-sqlite3")

const app = express()
const db = sqlite("database.db")

const sql = fs.readFileSync(
    path.resolve(__dirname, "schema.sql"),
    "utf-8"
)
db.exec(sql)

app.use(express.static(
    path.resolve(__dirname, "public")
))

app.use(express.urlencoded({
    extended: true
}))

app.use(express.json())

//product APIs

app.get("/api/product/:id", (req, res) => {
    try {
        const productID = req.params.id

        const query = db.prepare("SELECT * FROM products WHERE id=?")
        const data = query.get(productID)
        
        if(data === undefined) {
            res.sendStatus(404)
        } else {
            res.send(data)
        }
    } catch(err) {
        res.sendStatus(500)
    }
})

app.post("/api/product/new", (req, res) => {
    if(req.body.productname === undefined || req.body.price === undefined || req.body.photo === undefined) {
        res.sendStatus(400)
    }

    try {
        db.prepare("INSERT INTO products (productname, price, photo, productdisc, photoalt) VALUES ($productname, $price, $photo, $productdisc, $photoalt)")
        .run({
            productname: req.body.productname,
            price: req.body.price,
            photo: req.body.photo,
            productdisc: req.body.productdisc,
            photoalt: req.body.photoalt
        })

        res.send()

    } catch(err) {
        console.log(err)    
        res.sendStatus(500)
    }
})

app.delete("/api/product/remove/:id", (req, res) => {
    
    const productID = req.params.id
    try {
        db.prepare("DELETE FROM products WHERE id=$id")
        .run({
            id: req.params.id
        })

        res.send(`product ${productID} deleted`)
    } catch(err) {
        res.sendStatus(500)
    }
})

//cart APIs

app.get("/api/cart", (req, res) => {
    try {
        const data = db.prepare("SELECT * FROM cart").all()

        res.send(data)
    } catch (err) {
        console.log(err)
        res.sendStatus(500)
    }
})

app.post("/api/cart/add", (req,res) => {
    try {
        db.prepare("INSERT INTO cart (productname, price) VALUES ($productname, $price)")
        .run({
            productname: req.body.productname,
            price: req.body.price,
        })

        res.send()

    } catch(err) {
        console.log(err)    
        res.sendStatus(500)
    }
})

app.delete("/api/cart/clear", (req, res) => {
    try {
        db.prepare("DELETE FROM cart").run()
    } catch(err) {
        console.log(err)
        res.sendStatus(500)
    }
})

app.listen(8080)