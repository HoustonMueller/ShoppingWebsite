CREATE TABLE IF NOT EXISTS products (
    id integer PRIMARY KEY,
    productname varchar(255) UNIQUE NOT NULL,
    price float NOT NULL,
    photo varchar(255) UNIQUE NOT NULL,
    productdisc varchar(255) NOT NULL,
    photoalt varchar(255)
);


CREATE TABLE IF NOT EXISTS cart (
    id integer PRIMARY KEY,
    productname varchar(255),
    price float
);