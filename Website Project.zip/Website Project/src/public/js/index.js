
function productClick(prodID) {
    window.location.href = `product.html?id=${prodID}`
}

const addError = (element, message) => {
    const next = element.nextElementSibling

    if(next && next.tagName === 'SPAN') {
        return
    }

    const error = document.createElement('span')
    error.innerHTML = message

    element.insertAdjacentElement('afterend', error)
}

const removeError = (element) => {
    const next = element.nextElementSibling

    if(next && next.tagName === 'SPAN') {
        next.remove()
    }
}

async function addToCart(event) {
    event.preventDefault()

    const form = event.target
    const productId = form.querySelector('input').dataset.productId
    const quantity = form.querySelector('input').value
    if(quantity === '' || isNaN(quantity)) {
        addError(form.querySelector('input'), "Must enter quantity")
    } else {
        removeError(form.querySelector('input'))
    }

    try {
        const response = await fetch(`/api/product/${productId}`)
        if (!response.ok) {
            throw new Error('Failed to fetch product details')
        }

        const productDetails = await response.json()

        for(let i = 0; i < quantity; i++) {
            const addToCartResponse = await fetch('/api/cart/add', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    productname: productDetails.productname,
                    price: productDetails.price
                }),
            });
    
            if (addToCartResponse.ok) {
                console.log('Product added to cart successfully')
            } else {
                throw new Error('Failed to add product to cart')
            }
        }
    } catch (error) {
        console.error('Error:', error)
    }
}