const form = document.forms['payment']

const addError = (element, message) => {
    const next = element.nextElementSibling

    if(next && next.tagName === 'SPAN') {
        return
    }

    const error = document.createElement('span')
    error.innerHTML = message

    element.insertAdjacentElement('afterend', error)
}

const removeError = (element) => {
    const next = element.nextElementSibling

    if(next && next.tagName === 'SPAN') {
        next.remove()
    }
}

form.onsubmit = (event) => {
    let valid = true
    event.preventDefault()
    
    if(form.cardNumber.value === '' || isNaN(form.cardNumber.value)) {
        addError(form.cardNumber, 'Must enter card number')
        valid = false
    } else {
        removeError(form.cardNumber)
    }

    if(form.expiryDate.value === '') {
        addError(form.expiryDate, 'Must enter expiry date')
        valid = false
    } else {
        removeError(form.expiryDate)
    }

    if(form.cvv.value === '' || isNaN(form.cvv.value)) {
        addError(form.cvv, 'Must enter CVV')
        valid = false
    } else {
        removeError(form.cvv)
    }

    if(form.name.value === '') {
        addError(form.name, 'Must enter cardholder name')
        valid = false
    } else {
        removeError(form.name)
    }

    if(valid) {
        window.location.href = "survey.html"
    }
}