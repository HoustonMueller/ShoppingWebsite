(
    () => {
        const q = window.location.search

        const search = new URLSearchParams(q)

        const id = search.get("id")

        fetch(`/api/product/${id}`)
        .then((res) => {
            if(res.ok) {
                return res.json()
            } else {
                throw res
            }
        }).then((data) => {
            const photo = document.getElementById("photo")
            photo.src = `${data.photo}`
            photo.alt = `${data.photoalt}`

            const name = document.getElementById("name")
            name.innerHTML = `${data.productname}`

            const disc = document.getElementById("disc")
            disc.innerHTML = `${data.productdisc}`

            const price = document.getElementById("price")
            price.innerHTML = `$${data.price}`

        }).catch((err) => {
            console.log(err)
        })
    }
)();

async function addToCart(event) {
    event.preventDefault();

    const q = window.location.search

    const search = new URLSearchParams(q)

    const id = search.get("id")
    const pid = document.getElementById("input")
    pid.setAttribute("data-product-id", id)

    const form = event.target
    const productId = form.querySelector('input').dataset.productId
    const quantity = form.querySelector('input').value

    try {
        const response = await fetch(`/api/product/${productId}`)
        if (!response.ok) {
            throw new Error('Failed to fetch product details')
        }

        const productDetails = await response.json();

        for(let i = 0; i < quantity; i++) {
            const addToCartResponse = await fetch('/api/cart/add', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    productname: productDetails.productname,
                    price: productDetails.price
                }),
            });
    
            if (addToCartResponse.ok) {
                console.log('Product added to cart successfully');
            } else {
                throw new Error('Failed to add product to cart');
            }
        }
    } catch (error) {
        console.error('Error:', error);
    }
}