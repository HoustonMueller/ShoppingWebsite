document.addEventListener("DOMContentLoaded", () => {
    const fetchCartItems = async () => {
        try {
            const response = await fetch('/api/cart')
            if (!response.ok) {
                throw new Error('Failed to fetch cart items')
            }

            const cartItems = await response.json()
            updateCartTable(cartItems)
        } catch (error) {
            console.error('Error:', error)
        }
    };

    const updateCartTable = (cartItems) => {
        const cartTableBody = document.getElementById('cart-items')
        const cartTotalElement = document.getElementById('cart-total')
        let total = 0

        cartTableBody.innerHTML = ''

        cartItems.forEach((item) => {
            const row = cartTableBody.insertRow()
            const productNameCell = row.insertCell(0)
            const priceCell = row.insertCell(1)

            productNameCell.textContent = item.productname
            priceCell.textContent = `$${item.price.toFixed(2)}`
            
            const itemTotal = item.price

            total += itemTotal
        });

        cartTotalElement.textContent = `Total: $${total.toFixed(2)}`
    };

    fetchCartItems()
})

const clearCart = () => {
    fetch("/api/cart/clear", {
        method: "DELETE",
    })
    .then(res => {
        if(res.ok) {
            console.log("Cart cleared")
        } else {
            console.log("failed to clear cart")
        }
    })
    .catch(err => console.log(err))

    window.location.href = "cart.html"
    }